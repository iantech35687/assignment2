import { BarChart as RechartsBarChart, LineChart as RechartsLineChart, PieChart as RechartsPieChart } from "recharts"

export const BarChart = ({ children, ...props }: any) => {
  return <RechartsBarChart {...props}>{children}</RechartsBarChart>
}

export const LineChart = ({ children, ...props }: any) => {
  return <RechartsLineChart {...props}>{children}</RechartsLineChart>
}

export const PieChart = ({ children, ...props }: any) => {
  return <RechartsPieChart {...props}>{children}</RechartsPieChart>
}

