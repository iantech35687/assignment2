import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"

const monthlyData = [
  { month: "Jan", sales: 24000, target: 22000 },
  { month: "Feb", sales: 26000, target: 24000 },
  { month: "Mar", sales: 32000, target: 28000 },
  { month: "Apr", sales: 28000, target: 30000 },
  { month: "May", sales: 35000, target: 32000 },
  { month: "Jun", sales: 42000, target: 36000 },
  { month: "Jul", sales: 38000, target: 38000 },
  { month: "Aug", sales: 36000, target: 40000 },
  { month: "Sep", sales: 40000, target: 42000 },
  { month: "Oct", sales: 45000, target: 44000 },
  { month: "Nov", sales: 48000, target: 46000 },
  { month: "Dec", sales: 52000, target: 48000 },
]

const quarterlyData = [
  { quarter: "Q1", sales: 82000, target: 74000, growth: 8.5 },
  { quarter: "Q2", sales: 105000, target: 98000, growth: 12.2 },
  { quarter: "Q3", sales: 114000, target: 120000, growth: 5.3 },
  { quarter: "Q4", sales: 145000, target: 138000, growth: 15.8 },
]

const yearlyData = [
  { year: "2018", sales: 320000, growth: 0 },
  { year: "2019", sales: 356000, growth: 11.3 },
  { year: "2020", sales: 382000, growth: 7.3 },
  { year: "2021", sales: 410000, growth: 7.3 },
  { year: "2022", sales: 446000, growth: 8.8 },
  { year: "2023", sales: 446000, growth: 0 },
]

const channelData = [
  { month: "Jan", Online: 14000, Retail: 10000 },
  { month: "Feb", Online: 16000, Retail: 10000 },
  { month: "Mar", Online: 20000, Retail: 12000 },
  { month: "Apr", Online: 18000, Retail: 10000 },
  { month: "May", Online: 22000, Retail: 13000 },
  { month: "Jun", Online: 26000, Retail: 16000 },
  { month: "Jul", Online: 24000, Retail: 14000 },
  { month: "Aug", Online: 22000, Retail: 14000 },
  { month: "Sep", Online: 25000, Retail: 15000 },
  { month: "Oct", Online: 28000, Retail: 17000 },
  { month: "Nov", Online: 30000, Retail: 18000 },
  { month: "Dec", Online: 34000, Retail: 18000 },
]

export default function SalesTrends() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Sales Trends</h1>
        <p className="text-muted-foreground">
          Analysis of sales performance over time across different timeframes and channels.
        </p>
      </div>

      <Tabs defaultValue="monthly">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
          <TabsTrigger value="quarterly">Quarterly</TabsTrigger>
          <TabsTrigger value="yearly">Yearly</TabsTrigger>
        </TabsList>
        <TabsContent value="monthly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Sales vs Target</CardTitle>
              <CardDescription>Performance against monthly targets for the current year</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sales" stroke="#8884d8" name="Actual Sales" strokeWidth={2} />
                    <Line
                      type="monotone"
                      dataKey="target"
                      stroke="#82ca9d"
                      name="Target"
                      strokeWidth={2}
                      strokeDasharray="5 5"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Monthly Sales by Channel</CardTitle>
              <CardDescription>Comparison of online vs retail store sales</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={channelData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="Online" stackId="1" stroke="#8884d8" fill="#8884d8" />
                    <Area type="monotone" dataKey="Retail" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Performance Highlights</CardTitle>
                <CardDescription>Key insights from monthly data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium">Best Performing Month</h3>
                    <p className="text-sm text-muted-foreground">
                      December with $52,000 in sales, exceeding target by 8.3%
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Worst Performing Month</h3>
                    <p className="text-sm text-muted-foreground">
                      January with $24,000 in sales, though still above target by 9.1%
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Largest Growth</h3>
                    <p className="text-sm text-muted-foreground">May to June with 20% month-over-month growth</p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Channel Insights</h3>
                    <p className="text-sm text-muted-foreground">
                      Online sales consistently outperform retail by an average of 65% across all months
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Monthly Performance Table</CardTitle>
                <CardDescription>Detailed monthly performance data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 text-left font-medium">Month</th>
                        <th className="py-2 text-right font-medium">Sales</th>
                        <th className="py-2 text-right font-medium">Target</th>
                        <th className="py-2 text-right font-medium">Variance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {monthlyData.slice(0, 6).map((item, index) => (
                        <tr key={index} className={index < 5 ? "border-b" : ""}>
                          <td className="py-2">{item.month}</td>
                          <td className="py-2 text-right">${item.sales.toLocaleString()}</td>
                          <td className="py-2 text-right">${item.target.toLocaleString()}</td>
                          <td className="py-2 text-right">
                            <span className={item.sales >= item.target ? "text-green-500" : "text-red-500"}>
                              {(((item.sales - item.target) / item.target) * 100).toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="quarterly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quarterly Sales vs Target</CardTitle>
              <CardDescription>Performance against quarterly targets for the current year</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={quarterlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="quarter" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="sales" fill="#8884d8" name="Actual Sales" />
                    <Bar dataKey="target" fill="#82ca9d" name="Target" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Quarterly Growth Rate</CardTitle>
              <CardDescription>Year-over-year growth percentage by quarter</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={quarterlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="quarter" />
                    <YAxis unit="%" />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="growth" stroke="#ff7300" name="Growth Rate" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Quarterly Performance Analysis</CardTitle>
              <CardDescription>Detailed breakdown of quarterly performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Q1 Analysis</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Strong start to the year with sales exceeding target by 10.8%. Key drivers were new product
                      launches and post-holiday promotions.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Performance:</span>
                      <span className="text-green-500">Above Target</span>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium mb-2">Q2 Analysis</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Continued strong performance with 12.2% growth. Summer product lines performed exceptionally well,
                      particularly in June.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Performance:</span>
                      <span className="text-green-500">Above Target</span>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium mb-2">Q3 Analysis</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Slight underperformance against target by 5%, but still showing positive growth of 5.3%
                      year-over-year. Back-to-school promotions didn't perform as expected.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Performance:</span>
                      <span className="text-red-500">Below Target</span>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium mb-2">Q4 Analysis</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Strongest quarter of the year with 15.8% growth and exceeding target by 5.1%. Holiday season sales
                      were exceptional, particularly in the online channel.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Performance:</span>
                      <span className="text-green-500">Above Target</span>
                    </div>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 text-left font-medium">Quarter</th>
                        <th className="py-2 text-right font-medium">Sales</th>
                        <th className="py-2 text-right font-medium">Target</th>
                        <th className="py-2 text-right font-medium">Growth</th>
                        <th className="py-2 text-right font-medium">Variance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {quarterlyData.map((item, index) => (
                        <tr key={index} className={index < quarterlyData.length - 1 ? "border-b" : ""}>
                          <td className="py-2">{item.quarter}</td>
                          <td className="py-2 text-right">${item.sales.toLocaleString()}</td>
                          <td className="py-2 text-right">${item.target.toLocaleString()}</td>
                          <td className="py-2 text-right">{item.growth}%</td>
                          <td className="py-2 text-right">
                            <span className={item.sales >= item.target ? "text-green-500" : "text-red-500"}>
                              {(((item.sales - item.target) / item.target) * 100).toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="yearly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Annual Sales Trend</CardTitle>
              <CardDescription>Sales performance over the last 6 years</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={yearlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sales" stroke="#8884d8" name="Annual Sales" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Annual Growth Rate</CardTitle>
              <CardDescription>Year-over-year growth percentage</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={yearlyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis unit="%" />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="growth" fill="#82ca9d" name="Growth Rate" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Long-term Trend Analysis</CardTitle>
                <CardDescription>Key insights from annual data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium">Compound Annual Growth Rate (CAGR)</h3>
                    <p className="text-sm text-muted-foreground">
                      6.9% CAGR over the past 5 years, indicating steady and sustainable growth.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Growth Slowdown</h3>
                    <p className="text-sm text-muted-foreground">
                      2023 showed flat growth compared to 2022, potentially indicating market saturation or economic
                      factors.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Best Growth Year</h3>
                    <p className="text-sm text-muted-foreground">
                      2019 with 11.3% growth, coinciding with expansion into new markets and product lines.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">Future Projection</h3>
                    <p className="text-sm text-muted-foreground">
                      Based on historical trends, projected growth of 5-7% for 2024, with potential upside from new
                      product launches.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Annual Performance Table</CardTitle>
                <CardDescription>Detailed annual performance data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 text-left font-medium">Year</th>
                        <th className="py-2 text-right font-medium">Sales</th>
                        <th className="py-2 text-right font-medium">Growth</th>
                        <th className="py-2 text-left font-medium">Key Events</th>
                      </tr>
                    </thead>
                    <tbody>
                      {yearlyData.map((item, index) => (
                        <tr key={index} className={index < yearlyData.length - 1 ? "border-b" : ""}>
                          <td className="py-2">{item.year}</td>
                          <td className="py-2 text-right">${item.sales.toLocaleString()}</td>
                          <td className="py-2 text-right">{item.growth}%</td>
                          <td className="py-2">
                            {item.year === "2018" && "Market entry in Europe"}
                            {item.year === "2019" && "New product line launch"}
                            {item.year === "2020" && "Pandemic impact, shift to online"}
                            {item.year === "2021" && "Supply chain optimization"}
                            {item.year === "2022" && "Expansion to Asia markets"}
                            {item.year === "2023" && "Economic slowdown, cost cutting"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Sales Forecast</CardTitle>
          <CardDescription>Projected sales for the next 6 months based on historical trends</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={[
                  ...monthlyData.slice(6),
                  { month: "Jan", sales: 26000, target: 24000, forecast: true },
                  { month: "Feb", sales: 28000, target: 26000, forecast: true },
                  { month: "Mar", sales: 34000, target: 30000, forecast: true },
                  { month: "Apr", sales: 30000, target: 32000, forecast: true },
                  { month: "May", sales: 37000, target: 34000, forecast: true },
                  { month: "Jun", sales: 44000, target: 38000, forecast: true },
                ]}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="sales"
                  stroke="#8884d8"
                  name="Actual/Forecast Sales"
                  strokeWidth={2}
                  strokeDasharray={(d) => (d.forecast ? "5 5" : "0")}
                />
                <Line type="monotone" dataKey="target" stroke="#82ca9d" name="Target" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

