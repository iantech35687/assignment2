import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
} from "recharts"

const topProducts = [
  { name: "Product A", sales: 18000, growth: 15 },
  { name: "Product B", sales: 15000, growth: 8 },
  { name: "Product C", sales: 12000, growth: 12 },
  { name: "Product D", sales: 10000, growth: 5 },
  { name: "Product E", sales: 9000, growth: 3 },
]

const bottomProducts = [
  { name: "Product V", sales: 2000, growth: -12 },
  { name: "Product W", sales: 2500, growth: -8 },
  { name: "Product X", sales: 3000, growth: -5 },
  { name: "Product Y", sales: 3500, growth: -3 },
  { name: "Product Z", sales: 4000, growth: -1 },
]

const productCategories = [
  { name: "Electronics", sales: 45000, growth: 12 },
  { name: "Furniture", sales: 32000, growth: 8 },
  { name: "Clothing", sales: 28000, growth: 5 },
  { name: "Appliances", sales: 22000, growth: 7 },
  { name: "Accessories", sales: 18000, growth: 10 },
]

const monthlyProductData = [
  { month: "Jan", "Product A": 1200, "Product B": 900, "Product C": 800, "Product D": 700, "Product E": 600 },
  { month: "Feb", "Product A": 1300, "Product B": 950, "Product C": 850, "Product D": 750, "Product E": 650 },
  { month: "Mar", "Product A": 1400, "Product B": 1000, "Product C": 900, "Product D": 800, "Product E": 700 },
  { month: "Apr", "Product A": 1500, "Product B": 1100, "Product C": 950, "Product D": 850, "Product E": 750 },
  { month: "May", "Product A": 1600, "Product B": 1200, "Product C": 1000, "Product D": 900, "Product E": 800 },
  { month: "Jun", "Product A": 1700, "Product B": 1300, "Product C": 1050, "Product D": 950, "Product E": 850 },
]

export default function ProductPerformance() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Product Performance</h1>
        <p className="text-muted-foreground">Analysis of top and bottom performing products and product categories.</p>
      </div>

      <Tabs defaultValue="top">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="top">Top Products</TabsTrigger>
          <TabsTrigger value="bottom">Bottom Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
        </TabsList>
        <TabsContent value="top" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Top 5 Products by Sales</CardTitle>
              <CardDescription>Highest performing products by total sales</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topProducts}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="sales" fill="#8884d8" name="Sales ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Top Products Growth Rate</CardTitle>
              <CardDescription>Year-over-year growth percentage</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topProducts}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="growth" fill="#82ca9d" name="Growth (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Top Products Monthly Performance</CardTitle>
              <CardDescription>Sales trends over the last 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyProductData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="Product A" stroke="#8884d8" />
                    <Line type="monotone" dataKey="Product B" stroke="#82ca9d" />
                    <Line type="monotone" dataKey="Product C" stroke="#ffc658" />
                    <Line type="monotone" dataKey="Product D" stroke="#ff8042" />
                    <Line type="monotone" dataKey="Product E" stroke="#0088fe" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="bottom" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Bottom 5 Products by Sales</CardTitle>
              <CardDescription>Lowest performing products by total sales</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bottomProducts}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="sales" fill="#ff8042" name="Sales ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Bottom Products Growth Rate</CardTitle>
              <CardDescription>Year-over-year growth percentage (negative)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bottomProducts}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="growth" fill="#d88884" name="Growth (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Improvement Recommendations</CardTitle>
              <CardDescription>Strategies to improve underperforming products</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Product V</h3>
                  <p className="text-sm text-muted-foreground">
                    Consider rebranding or repositioning in the market. Current marketing strategy is ineffective.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium">Product W</h3>
                  <p className="text-sm text-muted-foreground">
                    Price point may be too high compared to competitors. Consider price adjustment or adding value
                    features.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium">Product X</h3>
                  <p className="text-sm text-muted-foreground">
                    Quality issues reported by customers. Review manufacturing process and implement quality control
                    measures.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium">Product Y</h3>
                  <p className="text-sm text-muted-foreground">
                    Limited market awareness. Increase marketing efforts and consider promotional campaigns.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium">Product Z</h3>
                  <p className="text-sm text-muted-foreground">
                    Product becoming obsolete. Consider product refresh or phasing out in favor of newer alternatives.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="categories" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Categories by Sales</CardTitle>
              <CardDescription>Performance comparison across product categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productCategories}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="sales" fill="#8884d8" name="Sales ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Category Growth Rates</CardTitle>
              <CardDescription>Year-over-year growth percentage by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productCategories}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="growth" fill="#82ca9d" name="Growth (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Category Details</CardTitle>
              <CardDescription>Detailed breakdown of product categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="py-2 text-left font-medium">Category</th>
                      <th className="py-2 text-left font-medium">Top Product</th>
                      <th className="py-2 text-right font-medium">Sales</th>
                      <th className="py-2 text-right font-medium">Growth</th>
                      <th className="py-2 text-left font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="py-2">Electronics</td>
                      <td className="py-2">Product A</td>
                      <td className="py-2 text-right">$45,000</td>
                      <td className="py-2 text-right">+12%</td>
                      <td className="py-2">
                        <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs">Growing</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2">Furniture</td>
                      <td className="py-2">Product F</td>
                      <td className="py-2 text-right">$32,000</td>
                      <td className="py-2 text-right">+8%</td>
                      <td className="py-2">
                        <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs">Growing</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2">Clothing</td>
                      <td className="py-2">Product K</td>
                      <td className="py-2 text-right">$28,000</td>
                      <td className="py-2 text-right">+5%</td>
                      <td className="py-2">
                        <span className="px-2 py-1 rounded-full bg-yellow-100 text-yellow-800 text-xs">Stable</span>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2">Appliances</td>
                      <td className="py-2">Product P</td>
                      <td className="py-2 text-right">$22,000</td>
                      <td className="py-2 text-right">+7%</td>
                      <td className="py-2">
                        <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs">Growing</span>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2">Accessories</td>
                      <td className="py-2">Product S</td>
                      <td className="py-2 text-right">$18,000</td>
                      <td className="py-2 text-right">+10%</td>
                      <td className="py-2">
                        <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs">Growing</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Product Feedback Form</CardTitle>
          <CardDescription>Submit feedback or suggestions for product improvements</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div className="grid gap-2">
              <label htmlFor="product" className="text-sm font-medium">
                Product
              </label>
              <select
                id="product"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="">Select a product</option>
                <option value="product_a">Product A</option>
                <option value="product_b">Product B</option>
                <option value="product_c">Product C</option>
                <option value="product_d">Product D</option>
                <option value="product_e">Product E</option>
              </select>
            </div>
            <div className="grid gap-2">
              <label htmlFor="feedback-type" className="text-sm font-medium">
                Feedback Type
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className="flex items-center space-x-2">
                  <input type="radio" name="feedback-type" value="improvement" className="h-4 w-4" />
                  <span>Improvement Suggestion</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="radio" name="feedback-type" value="issue" className="h-4 w-4" />
                  <span>Issue Report</span>
                </label>
              </div>
            </div>
            <div className="grid gap-2">
              <label htmlFor="feedback" className="text-sm font-medium">
                Feedback
              </label>
              <textarea
                id="feedback"
                className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                placeholder="Please provide your feedback or suggestions"
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="priority" className="text-sm font-medium">
                Priority
              </label>
              <select
                id="priority"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
            <button
              type="submit"
              className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground ring-offset-background transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50"
            >
              Submit Feedback
            </button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

